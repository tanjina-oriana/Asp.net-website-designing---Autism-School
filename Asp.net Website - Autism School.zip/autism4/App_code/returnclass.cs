﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
public class returnclass
{

    public string scalarReturn(string q)
    {
        string s;
        SqlConnection conn = new SqlConnection(@"Data Source=DESKTOP-DODHH2V\SAAD;Initial Catalog=trialdatabase;Integrated Security=True"); //connection obj
        conn.Open(); //opening connection
        try
        {
            SqlCommand cmd = new SqlCommand(q, conn); //querry execution

            s = cmd.ExecuteScalar().ToString();

        }
        catch (Exception)
        {

            s = " ";
        }
        conn.Close();

        return s;
    }
}
